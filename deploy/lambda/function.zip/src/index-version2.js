const querystring = require('qs');
const getPortalPackageDetails = require('./getPortalPackageDetails');
const generateSignedUrl = require('./generateSignedUrl');
const generateFormHtml = require('./generateFormHtml');
const generateFormHtmlFromLocalAsset = require('./generateFormHtmlFromLocalAsset');
const byteSize = require('byte-size');
const fetch = require('node-fetch');
const { compact } = require('lodash');

const { S3_BUCKET_NAME: s3Bucket } = process.env;

const FORM_REQUEST_PATH = '/form';
const PROCESS_FORM_PATH = '/processForm';

const info = {
    username: '<user>',
    password: '<password>',
};

const fetchBearer = async (info) => {
    const response = await fetch('https://na-1927-401-t.woexchange.com:8201/concepts/login', {
        method: 'POST',
        body: JSON.stringify(info),
        headers: {
            'Content-Type': ' application/json',
            Accept: ' application/json',
            credentials: ' same-origin',
        },
    });
    const data = await response.json();
    const token = data.token;
    console.log(`Token is ${token}`);
    return token;
};

const fetchSchedule = async () => {
    const token = await fetchBearer(info);
    const d = new Date();
    const day = d.getUTCDate();
    const day2 = d.getUTCDate() + 7;
    const month = d.getUTCMonth() + 1;
    const twoDigitMonth = month < 10 ? '0' + month : month;
    const twoDigitDay = day < 10 ? '0' + day : day;
    const twoDigitDay2 = day2 < 10 ? '0' + day2 : day2;
    const startDate = d.getFullYear() + `${twoDigitMonth}${twoDigitDay}`;
    const endDate = d.getFullYear() + `${twoDigitMonth}${twoDigitDay2}`;
    const response = await fetch(
        //        `https://na-1927-401-p.woexchange.com:9201/sincmedia/signiant?searchParameters=between(dateSelection,(${startDate},${endDate}));eq(natureSelection,Purchase)`,
        `https://na-1927-401-t.woexchange.com:8201/concepts/signiant?searchParameters=between(dateSelection,(${startDate},${endDate}));eq(natureSelection,Purchase)`,
        {
            method: 'GET',
            withCredentials: true,
            credentials: 'include',
            headers: {
                'Content-Type': ' application/json',
                Accept: ' application/json',
                credentials: ' same-origin',
                Authorization: ` Bearer ${token}`,
            },
        }
    );

    const data = await response.json();
    let seriesTitles = data.map((programme) => programme.tx_product.p_episode_seriestitle);
    let assetID = data.map((programme) => programme.tx_product.p_productcode);
    seriesTitles = compact(seriesTitles).sort(); // Remove NULLs and sort

    console.log(seriesTitles);
    console.log(assetID);
    return seriesTitles;
    return assetID;
};

const handleFormRequest = async (requestBody) => {
    // Extract the redirect URL passed by Media Shuttle in the request body. This is saved in the form as a hidden
    // form variable and used during form processing to return a response back to Media Shuttle.
    const { redirectUrl } = querystring.parse(requestBody);

    // Extract the Media Shuttle package endpoint url from the redirect URL. This endpoint can be invoked with a GET
    // request to retrieve package details prior displaying the metadata form for dynamic form generation. The package
    // endpoint url is the same as the redirectUrl without the /metadata suffix.
    const portalPackageUrl = redirectUrl.replace(/\/metadata$/, '');

    // Fetch package details from Media Shuttle and use them to fill in template values in the web form.
    const { sender, files, fileSize } = await getPortalPackageDetails(portalPackageUrl);
    const packageSize = byteSize(fileSize);

    const schedule = await fetchSchedule();

    const templateValues = {
        redirectUrl,
        sender,
        files,
        formattedPackageSize: `${packageSize.value} ${packageSize.unit}`,
        schedule,
    };

    // Generate the final metadata form HTML using the template values above.
    const formHtml = await generateFormHtml({ s3Bucket, templateValues });

    // Return the metadata form for Media Shuttle to display.
    return {
        statusCode: 200,
        headers: { 'Content-Type': 'text/html' },
        body: formHtml,
    };
};

const handleProcessFormRequest = (requestBody) => {
    // Any custom processing to be performed on the metadata form submitted would be done here. This sample simply
    // handles the minimal handshaking requirement with Media Shuttle by redirecting the form submission back to Media
    // Shuttle so that the metadata can be persisted to the Media Shuttle package repository and the Submit portal
    // upload can be completed.

    // Extract the redirect URL saved as a hidden form parameter when the metadata form was submitted.
    const { redirectUrl } = querystring.parse(requestBody);

    // Sign the redirect URL so that Media Shuttle can verify the authenticity of the redirect request.
    const signedUrl = generateSignedUrl({
        requestUrl: redirectUrl,
        requestBody,
    });

    return {
        statusCode: 307,
        headers: { Location: signedUrl },
    };
};

exports.handler = async (event) => {
    const { rawPath: path, body, isBase64Encoded } = event;
    const requestBody = isBase64Encoded ? Buffer.from(body, 'base64').toString('utf8') : body;

    if (path === FORM_REQUEST_PATH) {
        console.log(`Received request for metadata form with request data: ${JSON.stringify(requestBody)}`);
        return handleFormRequest(requestBody);
    }

    if (path === PROCESS_FORM_PATH) {
        console.log(`Received request to process metadata form with form data: ${JSON.stringify(requestBody)}`);
        return handleProcessFormRequest(requestBody);
    }

    return { status: 404 };
};

const run = async () => {
    const schedule = await fetchSchedule();

    const templateValues = {
        redirectUrl: 'TestRedirectUrl',
        sender: 'TestSender',
        files: ['TestFile1'],
        formattedPackageSize: `1 units`,
        schedule,
    };

    // Generate the final metadata form HTML using the template values above.
    const formHtml = await generateFormHtmlFromLocalAsset({ s3Bucket, templateValues });
    console.log(formHtml);
};

run();
